package com.company;

public class Task {

    private int taskID;
    private String description;

    Task(int taskID, String description){
        this.description = description;
        this.taskID = taskID;
    }

    /*
    public void setDescription(String description) {
        this.description = description;
    }

    public void setTaskID(int taskID) {
        this.taskID = taskID;
    }

    public int getTaskID() {
        return taskID;
    }

    public String getDescription() {
        return description;
    }
*/
}
