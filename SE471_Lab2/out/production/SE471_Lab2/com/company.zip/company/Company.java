package com.company;

public class Company {

    private String name;
    private String Address;

    public void hireNewEmployee(Employee e){

    // employee hired code here

    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;

    }

}
