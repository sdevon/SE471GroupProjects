package com.company;

public class Worker extends Employee{



    public Worker(String name, int phoneNumber) {
        super(name,phoneNumber);
    }

    public String toString() {
        return "Employee[Name=" + name +  "]";
    }

    public vode addTaskToWork(){

    }

    public void performTask(){

    }

    public void getTaskDone(){

    }

    public void getAssignedTask(){

    }

    public void setDeligate(){

    }

    public void addColleague(){

    }



}
